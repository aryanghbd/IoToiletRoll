package com.example.embeddedcw2

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import it.beppi.knoblibrary.Knob
import org.eclipse.paho.android.service.MqttAndroidClient
import org.eclipse.paho.client.mqttv3.*
import java.io.UnsupportedEncodingException


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val clientId = MqttClient.generateClientId()
        val client = MqttAndroidClient(
            this.applicationContext, "tcp://broker.hivemq.com:1883",
            clientId
        )

        try {
            val token = client.connect()
            token.actionCallback = object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken) {
                    // We are connected
                    Log.d("MQTTStuff", "onSuccess")
                }

                override fun onFailure(asyncActionToken: IMqttToken, exception: Throwable) {
                    // Something went wrong e.g. connection timeout or firewall problems
                    Log.d("MQTTStuff", "onFailure")
                }
            }
        } catch (e: MqttException) {
            e.printStackTrace()
        }
        val volumeknob : Knob = findViewById(R.id.vol_knob)
        val octaveknob : Knob = findViewById(R.id.octave_knob)
        volumeknob.state = 0
        octaveknob.state = 0
        volumeknob.setOnStateChanged{
            val volumeresult = volumeknob.state
            val volumetext = findViewById<TextView>(R.id.volume)
            volumetext.setText(volumeresult.toString())
            val topic = "volume"
            var encodedPayload = ByteArray(0)
            try {
                encodedPayload = volumeresult.toString().toByteArray(charset("UTF-8"))
                val message = MqttMessage(encodedPayload)
                client.publish(topic, message)
            } catch (e: UnsupportedEncodingException) {
                e.printStackTrace()
            } catch (e: MqttException) {
                e.printStackTrace()
            }
        }
        octaveknob.setOnStateChanged{
            val octaveresult = octaveknob.state
            val octavetext = findViewById<TextView>(R.id.octave)
            octavetext.setText(octaveresult.toString())
            val topic = "octave"
            var encodedPayload = ByteArray(0)
            try {
                encodedPayload = octaveresult.toString().toByteArray(charset("UTF-8"))
                val message = MqttMessage(encodedPayload)
                client.publish(topic, message)
            } catch (e: UnsupportedEncodingException) {
                e.printStackTrace()
            } catch (e: MqttException) {
                e.printStackTrace()
            }
        }
        }
    }
}